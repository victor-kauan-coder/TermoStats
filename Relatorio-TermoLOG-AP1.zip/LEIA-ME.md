# Relatório técnico de ciclo de projeto — modelo LaTeX

**Tópicos em Sistemas Computacionais I (IoT/AIoT) · UFPI · 2026.2**

Este é o modelo oficial da documentação de projeto da disciplina. Ele serve
às três avaliações parciais: trocar um número em um arquivo liga e desliga os
capítulos específicos de cada ciclo.

---

## Começar em cinco minutos

### No Overleaf (recomendado)

1. Descompacte nada: no Overleaf, **New Project → Upload Project** e envie o
   `.zip` como está.
2. Confirme que o arquivo principal é o `main.tex` **da raiz**
   (Menu → Main document). A pasta `exemplo/` tem um `main.tex` próprio; ele
   não deve ser o principal.
3. Aperte **Recompile**. O documento fecha sem erro já na primeira vez.
4. Abra `config/dados-da-equipe.tex` e preencha.

### Na sua máquina

Requer uma distribuição TeX com a classe `abntex2` (TeX Live completo, ou
`apt install texlive-publishers texlive-lang-portuguese texlive-latex-extra`).

```
latexmk -pdf main.tex
```

O `latexmkrc` já está configurado para rodar o BibTeX e as passagens
necessárias.

---

## O único arquivo que a equipe edita para configurar

`config/dados-da-equipe.tex`. Nada mais. Ele contém:

| O quê | Para quê |
|---|---|
| `\def\CICLO{1}` | **1**, **2** ou **3**. Define qual AP o relatório documenta. |
| `\def\MOSTRARNOTAS{}` | Liga as caixas cinzas de instrução. **Comente esta linha antes de entregar.** |
| título, subtítulo, equipe, repositório | vão para a capa e para os metadados do PDF |
| `\listaIntegrantes` | uma linha por integrante; alimenta a capa, a divisão de trabalho e a declaração de IA |
| dados institucionais e data | capa e folha de rosto |

### O que o `\CICLO` muda

| | AP1 | AP2 | AP3 |
|---|:--:|:--:|:--:|
| Problema, requisitos, arquitetura, implementação | ✓ | ✓ | ✓ |
| Cap. *Conectividade e conjunto de dados* | — | ✓ | ✓ |
| Cap. *Pipeline de dados, modelo e inferência embarcada* | — | — | ✓ |
| Testes, resultados, conclusão, apêndices | ✓ | ✓ | ✓ |
| Título do ciclo na capa e nas etiquetas de rubrica | automático | automático | automático |

---

## Estrutura das pastas

```
main.tex                    ordem dos capítulos; normalmente não se mexe
config/
  dados-da-equipe.tex       ← o arquivo da equipe
  pacotes.tex               pacotes e estilo de código
  comandos.tex              caixas de decisão, rubrica, vereditos
  estilo.tex                capa, folha de rosto, metadados
conteudo/
  00-resumo.tex             resumo e abstract
  00-siglas.tex             lista de siglas
  01-problema.tex           … até …
  09-conclusao.tex
apendices/
  A-mapa-de-barramento.tex  instrumento da Aula 06, já formatado
  B-orcamento-de-energia.tex instrumento da Aula 08, já formatado
  C-plano-de-testes.tex     um quadro por caso de teste
  D-declaracao-de-ia.tex    declaração de uso de IA generativa
figuras/                    coloque aqui as imagens do projeto
referencias.bib             bibliografia (ABNT, autor-data)
exemplo/                    relatório fictício completo, para consulta
```

Se você colocar um arquivo `figuras/logo-ufpi.png`, ele aparece no topo da capa
automaticamente.

---

## Comandos que valem a pena conhecer

**Caixa de decisão de projeto** — é o instrumento da fatia de 25 % da rubrica.
Numera sozinha (DP-1, DP-2, …) e aceita `\label`/`\ref`.

```latex
\begin{decisao}{Escolha do sensor de temperatura}
  \alternativas{NTC, DS18B20, PT100.}
  \criterio{Faixa útil abaixo de -20 °C e custo.}
  \escolha{DS18B20 estanque.}
  \evidencia{Dispersão de 18 contagens em cabo de 2 m; folha de dados.}
  \consequencia{Conversão de 750 ms obriga laço não bloqueante.}
\end{decisao}
```

**Procedência de um número** — `\folhadedados`, `\bancada`, `\estimativa`.
Estimativa é resposta legítima, desde que declarada.

**Vereditos de teste** — `\aprovado`, `\parcial`, `\reprovado`.

**Identificadores** — `\RF{01}`, `\RNF{02}`, `\CT{03}`, `\DP{1}`.

**Código do ESP32** —

```latex
\begin{lstlisting}[style=arduino, caption={...}, label={lst:laco}]
void loop() { ... }
\end{lstlisting}
```

**Citações ABNT** — `\cite{alfuqaha2015}` (entre parênteses) e
`\citeonline{alfuqaha2015}` (no corpo da frase).

---

## Onde cada capítulo responde à rubrica

A rubrica da AP é a mesma nos três ciclos. Cada capítulo traz, sob o título,
uma etiqueta discreta indicando a que fatia ele responde.

| Fatia da rubrica | Peso | Onde ela é ganha |
|---|:--:|---|
| Funcionalidade do protótipo | 30 % | Cap. 4 (implementação) e Cap. 6, na AP3 |
| Justificativa técnica das decisões | 25 % | Cap. 1, Cap. 3 (caixas DP-*n*) e Cap. 5, na AP2 |
| Robustez, testes e documentação | 25 % | Cap. 2 (critérios de aceitação), Cap. 7 e apêndices A a C |
| Comunicação dos resultados | 20 % | resumo, Cap. 8 e Cap. 9 |

Antes de entregar, confira na tabela de rastreabilidade (Seção 2.4) se todo
requisito tem implementação e caso de teste. É a checagem que mais rende.

---

## Antes de entregar

1. Comente `\def\MOSTRARNOTAS{}` em `config/dados-da-equipe.tex` e recompile.
2. Confira que não sobrou nenhuma reticência `\ldots` nem texto de exemplo.
3. Confira que o *commit* citado no Capítulo 4 existe no repositório.
4. Envie o **PDF** pelo SIGAA e deixe as fontes `.tex` em `docs/` no
   repositório da equipe.

---

## O exemplo preenchido

A pasta `exemplo/` traz um relatório de AP1 completo e fictício — o
*Sentinela*, monitor de temperatura de um freezer de amostras. Ele existe para
mostrar o **nível de detalhe** esperado, não para ser copiado: o projeto é
outro, o problema é outro e as decisões são outras.

Vale ler, em particular, três coisas que costumam faltar nos relatórios:

- a caixa **DP-4**, em que uma alternativa foi descartada por uma medição, e
  não por preferência;
- a seção **7.3, *O que falhou***, que descreve três erros reais e o que cada
  um ensinou;
- o fecho do **Apêndice B**, que identifica quem realmente dimensiona o
  sistema — e não é o firmware.

O exemplo declara dois requisitos não plenamente atendidos. Isso é
deliberado: relatório honesto sobre o que não funcionou vale mais, nesta
disciplina, do que relatório que declara sucesso em tudo.
